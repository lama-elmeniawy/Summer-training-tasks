# Campus Kites - Backend Authentication Module

## Description
This module provides complete authentication and user management capabilities for the Campus Kites platform using Express.js, MongoDB, Mongoose, JWT, and bcryptjs.

## User Roles
- **student**: Standard users capable of ordering campus kits.
- **courier**: Delivery agents responsible for handling local campus deliveries.
- **admin**: Platform administrators managing items and order statuses.

## API Endpoints

### 1. Sign Up
- **Route:** `POST /api/auth/signup`
- **Content-Type:** `multipart/form-data` or `application/json`
- **Request Body Example:**
  ```json
  {
    "firstName": "John",
    "lastName": "Doe",
    "email": "john.doe@example.com",
    "password": "password123",
    "phone": "+12345678901",
    "role": "student"
  }