const jwt = require("jsonwebtoken");

const generateToken = (id) => {
  return jwt.sign({ id }, process.env.JWT_SECRET || "supersecretkey123", {
    expiresIn: "7d",
  });
};

exports.signup = async (req, res) => {
  try {
    const token = generateToken("mock_user_id_123");
    res.status(201).json({
      status: "success",
      token,
      data: {
        user: {
          id: "mock_user_id_123",
          firstName: req.body.firstName || "Test",
          lastName: req.body.lastName || "User",
          email: req.body.email || "test@example.com",
          role: req.body.role || "student",
        },
      },
    });
  } catch (error) {
    res.status(400).json({ status: "error", message: error.message });
  }
};

exports.signin = async (req, res) => {
  try {
    const token = generateToken("mock_user_id_123");
    res.status(200).json({
      status: "success",
      token,
      data: {
        user: {
          id: "mock_user_id_123",
          email: req.body.email,
          role: "student",
        },
      },
    });
  } catch (error) {
    res.status(400).json({ status: "error", message: error.message });
  }
};