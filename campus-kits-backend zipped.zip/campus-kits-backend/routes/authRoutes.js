const express = require("express");
const router = express.Router();
const authController = require("../controllers/authController");
const upload = require("../middleware/upload");

router.post("/signup", upload.single("imageUrl"), authController.signup);
router.post("/signin", authController.signin);

module.exports = router;