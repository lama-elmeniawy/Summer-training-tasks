const express = require("express");
const dotenv = require("dotenv");

dotenv.config();

const app = express();
app.use(express.json());

const authRouter = require("./routes/authRoutes");
app.use("/api/auth", authRouter);

// Mock route to test protected endpoint
app.get("/api/items", (req, res) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ status: "error", message: "Unauthorized" });
  }

  res.status(200).json({
    status: "success",
    data: {
      items: [
        { id: 1, name: "Campus Kit A" },
        { id: 2, name: "Campus Kit B" },
      ],
    },
  });
});

console.log("Mock Database Connected Successfully!");

const PORT = process.env.PORT || 5001;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});